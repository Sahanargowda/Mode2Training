//Marker interface
public interface MyAnnotation {

}
