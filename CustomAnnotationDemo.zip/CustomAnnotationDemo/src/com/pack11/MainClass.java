package com.pack11;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Repeatable(Users.class)
@interface User {
	String name();

	int age();
}

@Retention(RetentionPolicy.RUNTIME)// retention policy RUNTIME will be available to the JVM through runtime.
@interface Users {
	User[] value();
}

@User(name = "disha", age = 20)
@User(name = "isha", age = 20)
public class MainClass {
	public static void main(String[] args) {
		User[] user = MainClass.class.getAnnotationsByType(User.class);
		for (User user1 : user) {
			System.out.println(user1.name());
		}
	}
}
