package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AccountDao;
import com.example.demo.dao.TransactionDao;
import com.example.demo.model.Account;
import com.example.demo.model.Transaction;


@Service
public class TransactionService {
	
	@Autowired
	private AccountDao accountDao;
 
	@Autowired
	private TransactionDao transactionDao;
	
	public String addTransaction(Transaction trans) {
		transactionDao.save(trans);
		return "Transaction details saved....";
		}
		
		public Iterable<Transaction> getAll() {
			return transactionDao.findAll();
		}
	
		public void transaction(Account acc1,Transaction trans1){
			if(trans1.getDescription().equals("debit")){
				
			}
		}
}
