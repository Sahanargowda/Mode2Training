package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Beneficiary;
import com.example.demo.model.Customer;
import com.example.demo.service.BeneficiaryService;

@RestController
public class BeneficiaryController {
	@Autowired
	BeneficiaryService beneficiaryService;
	
	@RequestMapping(value="/customer/add/beneficiary")
    public void addBeneficiary(@RequestBody Beneficiary bene){
		 beneficiaryService.addBeneficiary(bene);
	}
	
	@RequestMapping(value="/customer/getByIfsc/{ifsc}", method=RequestMethod.GET )
	public List<Beneficiary> getCustomerById(@PathVariable(value = "ifsc") String ifsc){
	return	beneficiaryService.getBeneficiaryCustomerByIfsc(ifsc);
	}
	@RequestMapping(value="/customer/getByIfsc/{ifsc}/bacc/{beneficiary_acc}", method=RequestMethod.GET )
	public List<Beneficiary> getCustomerById(@PathVariable(value = "ifsc") String ifsc1,@PathVariable(value = "beneficiary_acc") String b_acc1 ){
	return	beneficiaryService.getBeneficiaryCustomerByIfscAndBacc(ifsc1, b_acc1);
	}
}
