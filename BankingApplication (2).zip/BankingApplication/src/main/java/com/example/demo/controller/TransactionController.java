package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.customerDto.TransactionDto;
import com.example.demo.model.Account;
import com.example.demo.model.Transaction;
import com.example.demo.service.TransactionService;

@RestController
public class TransactionController {

	@Autowired
	TransactionService transactionService;

	@RequestMapping(value = "/transaction/add")
	public String addTransaction(@RequestBody Transaction trans) {
		return transactionService.addTransaction(trans);
	}

	@RequestMapping(value = "/transaction/get", method = RequestMethod.GET)
	public Iterable<Transaction> getAll() {
		return transactionService.getAll();
	}

	// Transaction without using Dto
	@RequestMapping(value = "/transaction/trans/{cust_acc}")
	public String transaction1(@PathVariable(value = "cust_acc") String to_cust, @RequestBody Transaction trans,
			Account acc) {
		return transactionService.transaction1(trans, acc, to_cust);
	}

	// Transaction using Dto
	@RequestMapping(value = "/transaction/trans")
	public String transaction2(@RequestBody TransactionDto transDto) {
		return transactionService.transaction2(transDto);
	}

	// Self Transaction
	@RequestMapping(value = "/transaction/trans/atm")
	public String transaction3(@RequestBody TransactionDto transDto) {
		return transactionService.transaction3(transDto);
	}

	// Pagination and sorting
	@GetMapping(value = "/transaction/details")
	public ResponseEntity<List<Transaction>> getAllEmployees(@RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "30") Integer pageSize, @RequestParam(defaultValue = "accno") String sortBy) {
		List<Transaction> list = transactionService.getCustomerTransactionDetails(pageNo, pageSize, sortBy);

		return new ResponseEntity<List<Transaction>>(list, new HttpHeaders(), HttpStatus.OK);
	}
}