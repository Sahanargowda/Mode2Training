package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.customerDto.CustomerDto;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerServiceimpl;

@RestController
public class CustomerController {

	@Autowired
	CustomerServiceimpl customerServiceImpl;
	 
	@RequestMapping(value="/customer/add")
    public String addCustomerDetails(@RequestBody Customer customer){
		
		return customerServiceImpl.addCustomerDetails(customer);
	}
	@RequestMapping(value="/customer/get", method=RequestMethod.GET )
	public Iterable<Customer> getAll( ){
		return	customerServiceImpl.getAll();
		}
	@RequestMapping(value="/customer/getId/{cust_id}", method=RequestMethod.GET )
	public Optional<Customer> getCustomerById(@PathVariable(value = "cust_id") Integer custId){
	return	customerServiceImpl.getCustomerById(custId);
	}
	
	/*@RequestMapping(value="/customer/delete/{cust_id}", method=RequestMethod.GET )*/
	@DeleteMapping("/customer/delete/{cust_id}")
	public void deleteById(@PathVariable(value = "cust_id") Integer custId1){
		customerServiceImpl.deleteById(custId1);
	}
	
	@PutMapping("/customer/update/{cust_id}")
	public void updateById(@PathVariable(value = "cust_id") Integer custId2,
	                                        @RequestBody Customer noteDetails) {
		customerServiceImpl.updateById(custId2, noteDetails);
	}
	
	@RequestMapping(value="/customer/getDto", method=RequestMethod.GET )
	public List<CustomerDto> getDto(){
		return	customerServiceImpl.getDto();
		}
	
}
