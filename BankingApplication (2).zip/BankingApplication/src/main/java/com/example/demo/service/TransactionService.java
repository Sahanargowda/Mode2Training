package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.example.demo.customerDto.TransactionDto;
import com.example.demo.dao.AccountDao;
import com.example.demo.dao.TransactionDao;
import com.example.demo.dao.TransactionDaoPagingAndSorting;
import com.example.demo.exception.AccountNotFoundException;
import com.example.demo.exception.InsufficientBalanceException;
import com.example.demo.model.Account;
import com.example.demo.model.Transaction;

@Service
public class TransactionService {

	ModelMapper modelMapper = new ModelMapper();
	List<TransactionDto> list = new ArrayList();

	float fromBalance, toBalance;

	@Autowired
	private AccountDao accountDao;

	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private TransactionDaoPagingAndSorting transactionDaoPagingAndSorting;

	public String addTransaction(Transaction trans) {
		transactionDao.save(trans);
		return "Details saved successfully";
	}

	public Iterable<Transaction> getAll() {
		return transactionDao.findAll();
	}
//Method to get transaction details using account number
	public String transaction1(Transaction trans1, Account acc1, String to_cust) {
		transactionDao.save(trans1);
		Transaction translist = transactionDao.findById(trans1.getAccno()).orElse(null);
		Account acclist1 = accountDao.findById(trans1.getAccno()).orElse(null);
		Account acclist2 = accountDao.findById(to_cust).orElse(null);
		if (acclist1.getCustomer_acc() == null) {
			throw new AccountNotFoundException("Account Number: " + acclist1.getCustomer_acc());
		}

		if (translist.getAmount() < acclist1.getBalance()) {
			System.out.println("You have sufficient balance to make transaction!!");
			fromBalance = acclist1.getBalance();
			toBalance = acclist2.getBalance();
			fromBalance = fromBalance - translist.getAmount();
			toBalance = toBalance + translist.getAmount();
			acclist1.setBalance(fromBalance);
			acclist2.setBalance(toBalance);
			accountDao.save(acclist1);
			accountDao.save(acclist2);
			trans1.setAccno(to_cust);
			trans1.setAmount(translist.getAmount());
			trans1.setDescription("Recieved from" + translist.getAccno());
			trans1.setTranscation_type("credited");
			transactionDao.save(trans1);
			return "Transaction Over";
		}
		return "Your balance is too low to  make  a transaction";
	}

	public String transaction2(TransactionDto transDto) {
		Account acc3 = new Account();
		list.add(modelMapper.map(acc3, TransactionDto.class));
		Account acclist1 = accountDao.findById(transDto.getFromcust_accno()).orElse(null);
		if (acclist1 == null) {
			throw new AccountNotFoundException("Account Not Found" + transDto.getFromcust_accno());

		}
		
		Account acclist2 = accountDao.findById(transDto.getTocust_accno()).orElse(null);
		Transaction trans = new Transaction();
		Transaction trans1 = new Transaction();
		trans.setAccno(transDto.getFromcust_accno());
		trans.setAmount(transDto.getCust_amount());
		trans.setDescription("sent to " + transDto.getTocust_accno());
		trans.setTranscation_type("Debit");
		transactionDao.save(trans);
		if (transDto.getCust_amount() < acclist1.getBalance()) {
			System.out.println("You have sufficient balance to make transaction!!");
			fromBalance = acclist1.getBalance();
			toBalance = acclist2.getBalance();
			fromBalance = fromBalance - transDto.getCust_amount();
			toBalance = toBalance + transDto.getCust_amount();
			acclist1.setBalance(fromBalance);
			acclist2.setBalance(toBalance);
			accountDao.save(acclist1);
			accountDao.save(acclist2);
			trans1.setAccno(transDto.getTocust_accno());
			trans1.setAmount(transDto.getCust_amount());
			trans1.setDescription("Received from " + transDto.getFromcust_accno());
			trans1.setTranscation_type("Credit");
			transactionDao.save(trans1);
			return "Transaction Over";
		}
		throw new InsufficientBalanceException("Transaction failed,  Your Balance: " + acclist1.getBalance());

	}
//Method to perform transactions
	public String transaction3(TransactionDto transDto) {
		Account acc3 = new Account();
		list.add(modelMapper.map(acc3, TransactionDto.class));
		Account acclist1 = accountDao.findById(transDto.getFromcust_accno()).orElse(null);
		Transaction trans = new Transaction();
		trans.setAccno(transDto.getFromcust_accno());
		trans.setAmount(transDto.getCust_amount());
		trans.setDescription("sent to " + transDto.getFromcust_accno());
		trans.setTranscation_type("Debit(ATM)");
		transactionDao.save(trans);
		if (transDto.getCust_amount() < acclist1.getBalance()) {
			System.out.println("You have sufficient balance to make transaction!!");
			fromBalance = acclist1.getBalance();
			fromBalance = fromBalance - transDto.getCust_amount();
			toBalance = toBalance + transDto.getCust_amount();
			acclist1.setBalance(fromBalance);
			accountDao.save(acclist1);
			return "Transaction Completed";
		}
		return "your balance is too low to make transaction";
	}
//to get transaction details of customers using paging and sorting method
	public List<Transaction> getCustomerTransactionDetails(Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

		Page<Transaction> pagedResult = transactionDaoPagingAndSorting.findAll(paging);

		if (pagedResult.hasContent()) {
			return pagedResult.getContent();
		} else {
			return new ArrayList<Transaction>();
		}
	}

}
