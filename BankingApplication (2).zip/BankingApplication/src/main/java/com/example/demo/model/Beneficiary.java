package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Beneficiary")
public class Beneficiary {
	@Id
	@Column(name = "customer_id")
	private String customer_id;
	@Column(name = "beneficiary_acc")
	private String beneficiary_acc;
	@Column(name = "ifsc")
	private String ifsc;
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getBeneficiary_acc() {
		return beneficiary_acc;
	}
	public void setBeneficiary_acc(String beneficiary_acc) {
		this.beneficiary_acc = beneficiary_acc;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	
}
