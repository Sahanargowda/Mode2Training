package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Beneficiary;

@Repository
public interface BeneficiaryDao extends JpaRepository<Beneficiary, String> {
	  List<Beneficiary> findByIfsc(String ifsc);
	  List<Beneficiary> findByIfscAndBacc(String ifsc1,String acc);

}
