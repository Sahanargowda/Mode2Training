package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "account")
public class Account {
	@Id
	@Column(name = "customer_acc")
	private String customer_acc;
	@Column(name = "balance")
	private float balance;

	public String getCustomer_acc() {
		return customer_acc;
	}

	public void setCustomer_acc(String customer_acc) {
		this.customer_acc = customer_acc;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

}
