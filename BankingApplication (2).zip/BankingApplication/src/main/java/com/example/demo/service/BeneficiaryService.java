package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BeneficiaryDao;
import com.example.demo.model.Beneficiary;
import com.example.demo.model.Customer;

@Service
public class BeneficiaryService {

	@Autowired
	private BeneficiaryDao beneficiaryDao;
	
	public void addBeneficiary(Beneficiary beni) {
		beneficiaryDao.save(beni);
	}
	
	public List<Beneficiary> getBeneficiaryCustomerByIfsc(String ifsc) {
		return beneficiaryDao.findByIfsc(ifsc);
	}
	
	public List<Beneficiary> getBeneficiaryCustomerByIfscAndBacc(String ifsc1,String beneficiary_acc) {
		return beneficiaryDao.findByIfscAndBacc(ifsc1, beneficiary_acc);
	}
}
